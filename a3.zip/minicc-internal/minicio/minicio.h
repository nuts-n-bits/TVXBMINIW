extern int getint();

extern void putint(int v);

extern void putcharacter(char c);

extern void putnewline();
