// Test 2: Loops

char x;

int main(int argc, int argd) {
    x = '@';
    return 0;
}
