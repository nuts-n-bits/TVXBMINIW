// Private 1: Simple assignments
#include "minicio.h"

// Test 2: Loops


int main() {
    if (x=5) 
        for (;;) {} 
    else
    {{{{{{{{{{{{{{{{{{{{{{{int p[4773345525];}}}}}}}}}}}}}}}}}}}}}}}
    p[calliing(53535)];
    return !0;
}

// Private 1: Simple assignments


// bool alpha, beta;
// int delta, epsilon;

// void main() {
//    // alpha = true;
//     beta = alpha;

//     delta = -1;
//   //  epsilon = delta + 1;
// //
//    putint(delta);
//    putnewline();
//    putint(epsilon);

//     return;
// }

// int i, result;

// int fib(int t) {
//     if (t < 1) 
//         return 0;
//     if (t == 1)
//         return 1;
//     return fib(t - 1) + fib(t - 2);
// }

// int main() {
//     i = 10;
//     result = fib(i);
//     putint(result);
//     return 0;
// }