// Test 1: Variable assignment

int alice, bob, charlie;
bool zeta;
char asterisk;

void main() {
    alice = 1;
    bob = 2;
    charlie = 3;
    zeta = false;
    asterisk = '*';
}